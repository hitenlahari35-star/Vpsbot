# Rex Studio VPS Bot
Ubuntu 24.04 + systemd containers, connect with sshx, QEMU guard.
Update: upload the zip to /root and run the one-line command from chat. Fresh install: venv + pip install -r requirements.txt,
docker build -t rex-systemd:24.04 - < Dockerfile, copy .env.example to .env, run bot.py.
User: >manage [n]  >sshx [n]   Admin: >manage @user [n]  >create  >delete  >suspend  >unsuspend  >userinfo  >setlimit  >list  >stats  >resize  >reinstall  >transfer
