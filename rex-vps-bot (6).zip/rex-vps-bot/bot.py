import fcntl, sys, os, re, io, json, time, random, asyncio, secrets, signal, threading
import discord, docker
from discord.ext import commands
from dotenv import load_dotenv
load_dotenv()

_lk = open("/tmp/rexbot.lock", "a+")
try: fcntl.flock(_lk, fcntl.LOCK_EX | fcntl.LOCK_NB); _lk.seek(0); _lk.truncate(); _lk.write(str(os.getpid())); _lk.flush()
except OSError:
    _lk.seek(0); _pid = _lk.read().strip() or "?"
    sys.exit(f"Another bot instance is already running (PID {_pid}). Stop it with:  kill -9 {_pid}   (or: pkill -9 -f bot.py)")

E = os.getenv
BASE = os.path.dirname(os.path.abspath(__file__))
TOKEN, PREFIX = E("DISCORD_TOKEN"), E("PREFIX", ">")
MAIN = int(E("MAIN_ADMIN_ID") or (E("ADMIN_IDS", "0").split(",")[0] or 0))
D_RAM, D_CPU, D_DISK = float(E("DEFAULT_RAM", 2)), float(E("DEFAULT_CPU", 1)), float(E("DEFAULT_DISK", 10))
LIMIT = int(E("CONTAINER_LIMIT", 1))
QEMU_ACTION = E("QEMU_ACTION", "suspend").lower()          # suspend | delete
LOG_CHANNEL = int(E("LOG_CHANNEL_ID") or 0)
PROXY = E("PROXY") or None                              # optional http://user:pass@host:port (use if Discord blocks this IP)                # optional: channel for QEMU alerts (else main admin DM)
IMAGE, PLAIN = "rex-systemd:24.04", "ubuntu:24.04"; IMG = [IMAGE]
DBF, AF, LF = (os.path.join(BASE, f) for f in ("vps.json", "admins.json", "limits.json"))

# ---------------- data ----------------
lock = threading.RLock()
def load():
    with lock: return json.load(open(DBF)) if os.path.exists(DBF) else []
def save(d):
    with lock: json.dump(d, open(DBF, "w"), indent=2)
def update(vid, **kw):
    with lock:
        db = load()
        for x in db:
            if x["id"] == vid: x.update(kw)
        save(db)
def find(vid): return next((x for x in load() if x["id"] == vid), None)
def vnum(v):                                    # per-user number: #1, #2 ...
    if v.get("num"): return v["num"]
    return [x["id"] for x in load() if x["owner"] == v["owner"]].index(v["id"]) + 1
def mine(uid): return sorted((v for v in load() if v["owner"] == uid), key=vnum)
def pick(vs, num): return (next((x for x in vs if vnum(x) == num), None)) if num else vs[0]
def ulimit(uid):
    d = json.load(open(LF)) if os.path.exists(LF) else {}
    return int(d.get(str(uid), LIMIT))
def admins():
    if not os.path.exists(AF): json.dump([int(x) for x in E("ADMIN_IDS", "").split(",") if x.strip()], open(AF, "w"))
    return set(json.load(open(AF))) | {MAIN}
def is_admin(uid): return uid in admins()

# ---------------- docker ----------------
dk = docker.from_env(); IMG_READY = threading.Event()
def ensure_image():
    try:
        try: dk.images.get(IMAGE)
        except docker.errors.ImageNotFound:
            print("Building", IMAGE, "(one time, ~3 min)...", flush=True)
            try: dk.images.build(fileobj=io.BytesIO(open(os.path.join(BASE, "Dockerfile"), "rb").read()), tag=IMAGE, rm=True)
            except Exception as e:
                print("Build failed -> using plain ubuntu:24.04 (no systemd):", repr(e), flush=True); IMG[0] = PLAIN
                try: dk.images.get(PLAIN)
                except docker.errors.ImageNotFound: dk.images.pull(PLAIN)
    finally: IMG_READY.set()

def new_record(owner, ram, cpu, disk):          # instant: only picks number + id
    with lock:
        db = load(); vid = secrets.token_hex(3)
        nums = {vnum(x) for x in db if x["owner"] == owner}; n = 1
        while n in nums: n += 1
        v = dict(id=vid, num=n, owner=owner, name=f"rex-{vid}", ram=ram, cpu=cpu, disk=disk, pending=True)
        db.append(v); save(db); return v

PROV, STORAGE_OPT = {}, [True]
# for containers where real systemd cannot boot: clears stuck apt locks, installs curl/python3 and a systemctl replacement
SETUP_SH = r'''
touch /var/log/rexsetup.started; rm -f /var/log/rexsetup.done
export DEBIAN_FRONTEND=noninteractive
for d in /proc/[0-9]*; do case "$(cat $d/comm 2>/dev/null)" in apt|apt-get|dpkg|aptitude) kill -9 ${d#/proc/} 2>/dev/null;; esac; done
sleep 1; rm -f /var/lib/apt/lists/lock /var/cache/apt/archives/lock /var/lib/dpkg/lock /var/lib/dpkg/lock-frontend
dpkg --configure -a >/dev/null 2>&1
apt-get update -qq >/dev/null 2>&1; apt-get install -y -qq curl ca-certificates python3 nano sudo procps >/dev/null 2>&1
[ -x /usr/local/bin/systemctl ] || curl -fsSL https://raw.githubusercontent.com/gdraheim/docker-systemctl-replacement/master/files/docker/systemctl3.py -o /usr/local/bin/systemctl
chmod +x /usr/local/bin/systemctl 2>/dev/null; ln -sf /usr/local/bin/systemctl /usr/bin/systemctl
touch /var/log/rexsetup.done
'''
SKIP_SH = 'test -x /usr/local/bin/systemctl || { [ -f /var/log/rexsetup.started ] && [ ! -f /var/log/rexsetup.done ] && [ -n "$(find /var/log/rexsetup.started -mmin -10)" ]; }'
def ensure_systemctl(c):
    try:
        if c.status != "running": return
        if c.exec_run(["cat", "/proc/1/comm"]).output.decode(errors="ignore").strip().startswith("systemd"): return   # real systemd: nothing to do
        if c.exec_run(["bash", "-c", SKIP_SH]).exit_code != 0: c.exec_run(["bash", "-c", SETUP_SH], detach=True)
    except Exception as e: print("ensure_systemctl:", repr(e), flush=True)

def rm_container(name):
    for _ in range(10):
        try: dk.containers.get(name).remove(force=True)
        except docker.errors.NotFound: return
        except Exception: time.sleep(0.5)

def run_kwargs(v, mode):                        # mode 0: systemd | 1: systemd + SYS_ADMIN | 2: plain (no systemd)
    kw = dict(image=IMG[0], name=v["name"], hostname=v["name"], detach=True, mem_limit=f"{int(v['ram']*1024)}m",
              nano_cpus=int(v["cpu"]*1e9), restart_policy={"Name": "unless-stopped"})
    if mode < 2:
        kw.update(cgroupns="host", volumes={"/sys/fs/cgroup": {"bind": "/sys/fs/cgroup", "mode": "rw"}}, tmpfs={"/run": "", "/run/lock": "", "/tmp": ""})
        if mode == 1: kw.update(cap_add=["SYS_ADMIN"], security_opt=["apparmor=unconfined"])
    else: kw.update(command=["sleep", "infinity"], tty=True, stdin_open=True, init=True)
    return kw

def booted(c, mode):
    time.sleep(0.8 if mode < 2 else 0.3); c.reload()
    if c.status != "running": return False
    return c.exec_run(["cat", "/proc/1/comm"]).output.decode(errors="ignore").strip().startswith("systemd") if mode < 2 else True

def provision(v):                               # ~1 sec: docker run on a local image; safe against double runs
    IMG_READY.wait(1200)
    with PROV.setdefault(v["id"], threading.Lock()):
        cur = find(v["id"])
        if not cur or not cur.get("pending"): return None
        err = None; modes = (0, 1, 2) if IMG[0] == IMAGE else (2,)
        for _ in range(2):
            for mode in modes:
                try:
                    rm_container(v["name"]); kw = run_kwargs(v, mode); c = None
                    if STORAGE_OPT[0]:          # disk quota needs overlay2 on xfs+pquota; skip it if unsupported
                        try: c = dk.containers.run(storage_opt={"size": f"{v['disk']:g}G"}, **kw)
                        except docker.errors.APIError as e:
                            if "storage" in str(e).lower(): STORAGE_OPT[0] = False
                            rm_container(v["name"])
                    if c is None: c = dk.containers.run(**kw)
                    if booted(c, mode): update(v["id"], pending=False, systemd=(mode < 2)); ensure_systemctl(c); tune_apt(c); return None
                    err = RuntimeError("container did not boot: " + c.logs(tail=5).decode(errors="ignore")[-200:])
                except Exception as ex: err = ex
                print(f"provision {v['name']} mode {mode} failed: {str(err)[:200]}", flush=True)
            time.sleep(1)
        return err

def tune_apt(c):                                # IPv6 stalls make apt "ultra slow" on many hosts -> force IPv4
    try:
        if c.status == "running":
            c.exec_run(["bash", "-c", "echo 'Acquire::ForceIPv4 \"true\";' > /etc/apt/apt.conf.d/99ipv4"])
    except Exception: pass

def heal(v):                                    # container vanished (docker reset / storage change) -> recreate it
    cur = find(v["id"])
    if cur and not cur.get("pending") and not cur.get("suspended"):
        update(v["id"], pending=True); threading.Thread(target=provision, args=(cur,), daemon=True).start()

def cont(v):
    try: return dk.containers.get(v["name"])
    except docker.errors.NotFound:
        heal(v); raise RuntimeError("VPS container was missing, it is being recreated now. Try again in ~15 seconds.")

def reconcile(start_stopped=False, systemd=False):   # boots everything: recreates missing containers, optionally starts stopped ones
    started = recreated = upgraded = 0
    for v in load():
        if v.get("suspended"): continue
        if v.get("pending"): threading.Thread(target=provision, args=(v,), daemon=True).start(); recreated += 1; continue
        try: c = dk.containers.get(v["name"])
        except docker.errors.NotFound:
            update(v["id"], pending=True); threading.Thread(target=provision, args=(v,), daemon=True).start(); recreated += 1; continue
        except Exception: continue
        ensure_systemctl(c); tune_apt(c)
        if systemd and IMG[0] == IMAGE and not v.get("systemd"):      # WIPES that VPS: fresh container with systemd
            update(v["id"], pending=True); threading.Thread(target=provision, args=(v,), daemon=True).start(); upgraded += 1; continue
        if start_stopped and c.status != "running":
            try: c.start(); started += 1
            except Exception: pass
    return started, recreated, upgraded
def specs(v): return f"**RAM:** {v['ram']:g} GB\n**CPU:** {v['cpu']:g} Core(s)\n**Disk:** {v['disk']:g} GB\n**OS:** Ubuntu 24.04"

def info(v):
    from datetime import datetime, timezone
    c = cont(v); now = datetime.now(timezone.utc); P = "%Y-%m-%dT%H:%M:%S"
    cr = datetime.strptime(c.attrs["Created"][:19], P).replace(tzinfo=timezone.utc); up = 0
    if c.status == "running":
        up = (now - datetime.strptime(c.attrs["State"]["StartedAt"][:19], P).replace(tzinfo=timezone.utc)).total_seconds()
    return dict(st=c.status, up=int(up), created=int(cr.timestamp()), cid=c.id, short=c.short_id)

def bar(p, n=12):
    p = max(0, min(100, p)); f = round(p / 100 * n); return "█" * f + "░" * (n - f)

def live(v):
    c = cont(v); d = dict(st=c.status, cpu=0.0, mem=0.0, up="—")
    if d["st"] == "running":
        st = c.stats(stream=False); cs, ps = st["cpu_stats"], st["precpu_stats"]
        dc = cs["cpu_usage"]["total_usage"] - ps["cpu_usage"]["total_usage"]
        ds = cs.get("system_cpu_usage", 0) - ps.get("system_cpu_usage", 0)
        d["cpu"] = ((dc / ds * (cs.get("online_cpus") or 1)) if ds > 0 else 0) / v["cpu"] * 100
        m = st["memory_stats"]; sx = m.get("stats", {})
        d["mem"] = (m.get("usage", 0) - sx.get("inactive_file", sx.get("cache", 0))) / 1048576
        s = info(v)["up"]; d["up"] = f"{s // 86400}d {s % 86400 // 3600}h {s % 3600 // 60}m"
    return d

# ---------------- sshx ----------------
SSHX_SH = r'''
F="/usr/local/bin/sshx /root/.local/bin/sshx /root/.sshx/bin/sshx"
S=$(command -v sshx || ls $F 2>/dev/null | head -1)
if [ -f /var/log/rexsetup.started ] && [ ! -f /var/log/rexsetup.done ]; then for i in $(seq 45); do [ -f /var/log/rexsetup.done ] && break; sleep 1; done; fi
if [ -z "$S" ]; then command -v curl >/dev/null || (apt-get update -qq && apt-get install -y -qq curl ca-certificates) >/dev/null 2>&1; curl -sSf https://sshx.io/get | sh >/tmp/sshx_install.log 2>&1; S=$(command -v sshx || ls $F 2>/dev/null | head -1); fi
if [ -z "$S" ]; then echo NOSSHX; tail -c 300 /tmp/sshx_install.log; exit 1; fi
for d in /proc/[0-9]*; do [ "$(cat $d/comm 2>/dev/null)" = sshx ] && kill ${d#/proc/} 2>/dev/null; done
rm -f /tmp/sshx.log
setsid nohup "$S" $1 > /tmp/sshx.log 2>&1 < /dev/null &
echo STARTED
'''
def run_sshx(v):
    c = cont(v)
    if c.status != "running": raise RuntimeError("VPS is not running. Start it first.")
    dbg = ""
    for flag in ("-q", ""):
        out = c.exec_run(["bash", "-c", SSHX_SH, "x", flag]).output.decode(errors="ignore")
        if "NOSSHX" in out: return None, "sshx could not be installed in the VPS (no internet?)\n" + out[-300:]
        for _ in range(20):
            time.sleep(1)
            log = re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", "", c.exec_run("cat /tmp/sshx.log").output.decode(errors="ignore"))
            m = re.search(r"https://sshx\.io/s/\S+", log)
            if m: return m.group(0), ""
            if "unexpected argument" in log or "error" in log.lower(): break
        dbg = log
    return None, dbg or "no output from sshx"

async def sshx_flow(user, v, say, can_show):
    try: link, dbg = await asyncio.to_thread(run_sshx, v)
    except Exception as ex: return await say(f"❌ {ex}")
    if not link: return await say(f"❌ Could not get the sshx link.\n```{dbg[-600:]}```")
    try: await user.send(f"🔗 **SSHX link** for VPS **#{vnum(v)}** (anyone with this link gets a shell, don't share it):\n{link}"); await say("✅ SSHX link sent in your DM.")
    except discord.Forbidden: await say(f"⚠️ Your DMs are closed, here is your private link:\n{link}" if can_show else "❌ Open your DMs so I can send the sshx link.")

# ---------------- QEMU / nested-VM guard ----------------
BAD = ("qemu", "kvm", "firecracker", "cloud-hyper", "crosvm", "vboxheadless", "vboxsvc", "vmware-vmx", "bhyve")
INSTALLERS = {"apt", "apt-get", "dpkg", "aptitude"}
CMAP, PUNISHED, LOOP = {}, {}, [None]

def find_bad(proc="/proc", me=None):            # returns [(pid, pid_namespace, reason)] for suspicious processes
    hits = []
    for p in os.listdir(proc):
        if not p.isdigit(): continue
        try:
            ns = os.readlink(f"{proc}/{p}/ns/pid")
            if ns == me: continue               # host processes are never touched
            comm = open(f"{proc}/{p}/comm").read().strip().lower(); why = None
            if comm.startswith(BAD): why = comm
            else:
                try: exe = os.path.basename(os.readlink(f"{proc}/{p}/exe")).lower()
                except OSError: exe = ""
                if exe.startswith(BAD): why = exe
                else:
                    cmd = " " + open(f"{proc}/{p}/cmdline", "rb").read().replace(b"\0", b" ").decode(errors="ignore").lower()
                    if comm in INSTALLERS and "qemu" in cmd: why = "installing qemu"
                    elif " -enable-kvm" in cmd or (" -smp " in cmd and (" -m " in cmd or " -drive " in cmd)): why = "qemu-style command"
            if why: hits.append((int(p), ns, why))
        except Exception: continue
    return hits

def refresh_cmap():
    m = {}
    for c in dk.containers.list(filters={"name": "rex-"}):
        try: m[os.readlink(f"/proc/{c.attrs['State']['Pid']}/ns/pid")] = c.name
        except Exception: pass
    CMAP.clear(); CMAP.update(m)

def punish(name, pid, why):                     # instant: kill the process, kill the container, suspend (or delete) the VPS
    if time.time() - PUNISHED.get(name, 0) < 10: return
    PUNISHED[name] = time.time()
    try: os.kill(pid, signal.SIGKILL)
    except Exception: pass
    try:
        c = dk.containers.get(name)
        try: c.update(restart_policy={"Name": "no"})
        except Exception: pass
        c.kill()
    except Exception: pass
    v = next((x for x in load() if x["name"] == name), None)
    if not v: return
    num, owner, vid = vnum(v), v["owner"], v["id"]
    reason = f"QEMU / nested VM detected ({why})"
    if QEMU_ACTION == "delete":
        rm_container(name); save([x for x in load() if x["id"] != vid])
    else: update(vid, suspended=True, reason=reason)
    print("QEMU GUARD:", name, why, QEMU_ACTION, flush=True)
    if LOOP[0]: asyncio.run_coroutine_threadsafe(notify_hit(owner, num, name, reason), LOOP[0])

async def notify_hit(owner, num, name, reason):
    act = "deleted" if QEMU_ACTION == "delete" else "suspended"
    e = deny("🚨 QEMU / Nested VM Detected", f"<@{owner}> VPS **#{num}** (`{name}`) was **{act} instantly**.\n**Reason:** {reason}")
    try:
        ch = bot.get_channel(LOG_CHANNEL) if LOG_CHANNEL else None
        if ch: await ch.send(embed=e)
        else: await (await bot.fetch_user(MAIN)).send(embed=e)
    except Exception as ex: print("notify error:", repr(ex))
    try: await (await bot.fetch_user(owner)).send(f"⛔ Your VPS **#{num}** was **{act}**: QEMU / nested virtualization is not allowed. Contact an admin.")
    except Exception: pass

def guard():
    print("QEMU guard started", flush=True)
    me = os.readlink("/proc/self/ns/pid"); last = 0
    while True:
        t0 = time.time()
        try:
            if time.time() - last > 3: refresh_cmap(); last = time.time()
            for pid, ns, why in find_bad(me=me):
                name = CMAP.get(ns)
                if not name: refresh_cmap(); last = time.time(); name = CMAP.get(ns)
                if name: punish(name, pid, why)
        except Exception as e: print("guard error:", repr(e), flush=True)
        time.sleep(max(0.3, (time.time() - t0) * 8))      # never use more than ~11% of one CPU

# ---------------- messages ----------------
def deny(t, d): return discord.Embed(title=t, description=d, color=0xed4245)
def ok(t, d, c=0x57f287): return discord.Embed(title=t, description=d, color=c, timestamp=discord.utils.utcnow())
def noreg(u): return f"{u.mention} your VPS is not registered. Contact an admin to create one."

def created_embed(v, target, i, status="Running"):
    sd = "systemd (booting)" if v.get("pending") else ("systemd (booted)" if v.get("systemd") else "no systemd")
    return discord.Embed(title="✅ VPS Created", color=0x57f287 if status == "Running" else 0xfee75c, description=(
        f"VPS created for {target.mention}.\n**Owner:** {target.mention}\n**Container:** `{v['name']}` (`{i['short']}`)\n"
        f"**VPS:** #{vnum(v)}\n**OS:** Ubuntu 24.04\n**Status:** {status}\n**VPS RAM Limit:** {v['ram']:.2f} GiB\n"
        f"**VPS CPU Limit:** {v['cpu']:g} cores\n**Created:** <t:{i['created']}:F>\n"
        f"**Features:** {sd} • sshx • curl + nano\n\nUse `{PREFIX}manage` to open the controls or `{PREFIX}sshx` to connect."))

def panel(v, owner="Unknown"):
    try: i = info(v)
    except Exception: i = dict(st="starting" if v.get("pending") else "missing", up=0, created=int(time.time()), cid="-", short="-")
    sus = v.get("suspended")
    st = "⛔ SUSPENDED" if sus else {"running": "Running", "exited": "Stopped", "starting": "Starting"}.get(i["st"], i["st"].title())
    d, r = divmod(i["up"], 86400); h, r = divmod(r, 3600)
    e = discord.Embed(title="🛠️ Rex Studio VPS Manager", color=0xed4245 if sus else 0x5865f2, description=(
        f"**Owner:** {owner} (`{v['owner']}`)\n**Container:** `{v['name']}` (`{i['short']}`)\n**Status:** {st}\n"
        + (f"**Reason:** {v.get('reason', 'No reason given')}\n" if sus else "") +
        f"**OS:** Ubuntu 24.04\n**systemd:** {'yes' if v.get('systemd') else 'no'}\n**VPS RAM Limit:** {v['ram']:.2f} GiB\n**VPS CPU Limit:** {v['cpu']:g} cores\n"
        f"**Uptime:** {d}d {h}h {r // 60}m\n**Creation Date:** <t:{i['created']}:F>"))
    e.set_footer(text=f"Owner ID: {v['owner']} • VPS #{vnum(v)} • VPS ID: {i['cid']} • Use the controls below"); return e

# ---------------- bot ----------------
bot = commands.Bot(command_prefix=PREFIX, intents=discord.Intents.all(), help_command=None, proxy=PROXY)
TASKS, STARTED = set(), [False]
def spawn(coro): t = asyncio.create_task(coro); TASKS.add(t); t.add_done_callback(TASKS.discard)

@bot.event
async def on_ready():
    LOOP[0] = asyncio.get_running_loop()
    await bot.change_presence(activity=discord.Game(f"{PREFIX}manage | {PREFIX}sshx"))
    print("Ready:", bot.user, flush=True)

def admin_only(): return commands.check(lambda ctx: is_admin(ctx.author.id))

@bot.event
async def on_command_error(ctx, e):
    if isinstance(e, commands.CheckFailure): await ctx.send(embed=deny("⛔ Access Denied", "Admins only."))
    elif isinstance(e, (commands.MemberNotFound, commands.BadArgument, commands.MissingRequiredArgument)):
        await ctx.send(f"❌ Wrong usage. See `{PREFIX}help`.")
    elif not isinstance(e, commands.CommandNotFound): print("ERR:", repr(e))

@bot.command()
async def create(ctx, *args):
    if not is_admin(ctx.author.id):
        return await ctx.send(embed=deny("⛔ Access Denied", "Only **admins** can create a VPS.\nContact an admin to get one."))
    target = ctx.message.mentions[0] if ctx.message.mentions else ctx.author
    nums = [float(a) for a in args if re.fullmatch(r"\d+(\.\d+)?", a)]
    ram, cpu, disk = (nums + [D_RAM, D_CPU, D_DISK][len(nums):])[:3]
    if len(mine(target.id)) >= ulimit(target.id):
        return await ctx.send(f"❌ {target.mention} already has the maximum of **{ulimit(target.id)}** VPS.")
    v = new_record(target.id, ram, cpu, disk); n = vnum(v)                 # instant
    st = "🟡 Starting (first-time image setup, please wait)" if not IMG_READY.is_set() else "🟡 Starting"
    msg = await ctx.send(f"✅ {target.mention} your VPS **#{n}** has been created!",       # instant: shown within ~1 sec
                         embed=created_embed(v, target, dict(short="starting...", created=int(time.time())), st))
    async def bg():
        try:
            err = await asyncio.to_thread(provision, v)
            if err is not None:
                save([x for x in load() if x["id"] != v["id"]])
                return await msg.edit(content=f"❌ {target.mention} VPS **#{n}** creation failed: `{str(err)[:300]}`", embed=None)
            v2 = find(v["id"]) or v; i = await asyncio.to_thread(info, v2)
            await msg.edit(content=f"✅ {target.mention} your VPS **#{n}** is ready!", embed=created_embed(v2, target, i))
        except Exception as ex: print("create error:", repr(ex))
    spawn(bg())

AUDITED = {"create", "delete", "suspend", "unsuspend", "reinstall", "transfer", "resize", "setlimit", "bootall", "addadmin", "removeadmin"}
async def audit(text):                          # admin actions are logged to LOG_CHANNEL_ID (if set)
    if not LOG_CHANNEL: return
    try:
        ch = bot.get_channel(LOG_CHANNEL) or await bot.fetch_channel(LOG_CHANNEL)
        await ch.send(text, allowed_mentions=discord.AllowedMentions.none())
    except Exception as e: print("audit error:", repr(e), flush=True)

@bot.event
async def on_command_completion(ctx):
    if ctx.command and ctx.command.name in AUDITED:
        await audit(f"🧾 **{ctx.author}** (`{ctx.author.id}`) ran `{ctx.message.content[:150]}`")

class Pager(discord.ui.View):
    def __init__(self, uid, pages): super().__init__(timeout=300); self.uid = uid; self.pages = pages; self.i = 0
    def embed(self):
        return discord.Embed(title=f"📋 All VPS — page {self.i + 1}/{len(self.pages)}", description="\n".join(self.pages[self.i]), color=0x5865f2)
    async def interaction_check(self, i):
        if i.user.id != self.uid: await i.response.send_message("Not your list.", ephemeral=True); return False
        return True
    @discord.ui.button(label="Prev", style=discord.ButtonStyle.secondary, emoji="◀️")
    async def prev(self, i, b): self.i = (self.i - 1) % len(self.pages); await i.response.edit_message(embed=self.embed(), view=self)
    @discord.ui.button(label="Next", style=discord.ButtonStyle.secondary, emoji="▶️")
    async def nxt(self, i, b): self.i = (self.i + 1) % len(self.pages); await i.response.edit_message(embed=self.embed(), view=self)

class Confirm(discord.ui.View):
    def __init__(self, parent): super().__init__(timeout=30); self.p = parent
    @discord.ui.button(label="Yes, delete forever", style=discord.ButtonStyle.danger, emoji="⚠️")
    async def yes(self, i, b):
        v = self.p.cur(); n = vnum(v)
        def rm():
            rm_container(v["name"]); save([x for x in load() if x["id"] != v["id"]])
        await asyncio.to_thread(rm); self.p.stop()
        await i.response.edit_message(content="🗑️ Deleted.", view=None)
        await audit(f"🧾 **{i.user}** deleted VPS **#{n}** (`{v['name']}`) of <@{v['owner']}> from the panel")
        try: await self.p.msg.edit(content=f"🗑️ VPS #{n} deleted.", embed=None, view=None)
        except Exception: pass
    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def no(self, i, b): await i.response.edit_message(content="Cancelled.", view=None)

class Act(discord.ui.Select):
    def __init__(self):
        super().__init__(placeholder="Choose a management action...", row=3, options=[
            discord.SelectOption(label="SSHX Link", value="sshx", emoji="🔑", description="Get your sshx connect link in DM"),
            discord.SelectOption(label="Refresh Panel", value="refresh", emoji="🔄", description="Update status & uptime")])
    async def callback(self, i):
        if self.values[0] == "sshx": await self.view.do_sshx(i)
        else: await self.view.refresh(i)

class Manage(discord.ui.View):
    def __init__(self, uid, vid, owner):
        super().__init__(timeout=600); self.uid = uid; self.vid = vid; self.owner = owner; self.msg = None; self.add_item(Act())
    def cur(self): return find(self.vid)
    async def interaction_check(self, i):
        v = self.cur()
        if i.user.id != self.uid: await i.response.send_message("Not your panel.", ephemeral=True); return False
        if not v: await i.response.send_message("This VPS no longer exists.", ephemeral=True); return False
        if v.get("suspended") and not is_admin(i.user.id): await i.response.send_message("⛔ This VPS is suspended. Contact an admin.", ephemeral=True); return False
        return True
    async def refresh(self, i, fn=None):
        await i.response.defer()
        if fn:
            try: await asyncio.to_thread(fn, self.cur())
            except Exception as ex: return await i.followup.send(f"❌ {ex}", ephemeral=True)
        await i.edit_original_response(embed=await asyncio.to_thread(panel, self.cur(), self.owner), view=self)
    async def do_sshx(self, i):
        await i.response.send_message("⏳ Starting sshx... the link will arrive in your DM (≈10 sec).", ephemeral=True)
        await sshx_flow(i.user, self.cur(), lambda t: i.followup.send(t, ephemeral=True), True)
    async def on_timeout(self):                 # grey out the buttons when the panel expires
        for c in self.children: c.disabled = True
        try: await self.msg.edit(view=self)
        except Exception: pass
    @discord.ui.button(label="Start", style=discord.ButtonStyle.success, emoji="▶️", row=0)
    async def b1(self, i, b): await self.refresh(i, lambda v: cont(v).start())
    @discord.ui.button(label="Stop", style=discord.ButtonStyle.secondary, emoji="⏹️", row=0)
    async def b2(self, i, b): await self.refresh(i, lambda v: cont(v).stop(timeout=3))
    @discord.ui.button(label="Restart", style=discord.ButtonStyle.primary, emoji="🔄", row=0)
    async def b3(self, i, b): await self.refresh(i, lambda v: cont(v).restart(timeout=3))
    @discord.ui.button(label="Live Stats", style=discord.ButtonStyle.primary, emoji="📊", row=1)
    async def b4(self, i, b):
        await i.response.defer(ephemeral=True); v = self.cur()
        try: l = await asyncio.to_thread(live, v)
        except Exception as ex: return await i.followup.send(f"❌ {ex}", ephemeral=True)
        if l["st"] != "running": return await i.followup.send("🔴 VPS is not running.", ephemeral=True)
        mb = v["ram"] * 1024; mp = l["mem"] / mb * 100
        await i.followup.send(embed=discord.Embed(title="📊 Live Stats", color=0x5865f2, description=
            f"`CPU {bar(l['cpu'])}` **{l['cpu']:.0f}%** of {v['cpu']:g} cores\n`RAM {bar(mp)}` **{mp:.0f}%** — {l['mem']:.0f} / {mb:.0f} MB\n**Uptime:** {l['up']}"), ephemeral=True)
    @discord.ui.button(label="SSHX", style=discord.ButtonStyle.primary, emoji="🔑", row=2)
    async def b5(self, i, b): await self.do_sshx(i)
    @discord.ui.button(label="Delete", style=discord.ButtonStyle.danger, emoji="🗑️", row=2)
    async def b6(self, i, b): await i.response.send_message("⚠️ Delete this VPS permanently?", view=Confirm(self), ephemeral=True)

@bot.command()
async def manage(ctx, *args):                   # >manage  |  >manage 2  |  admin: >manage @user [number]
    nums = [int(a) for a in args if a.isdigit()]; num = nums[0] if nums else None
    target = ctx.message.mentions[0] if ctx.message.mentions else ctx.author
    if target.id != ctx.author.id and not is_admin(ctx.author.id):
        return await ctx.send(embed=deny("⛔ Access Denied", "Only admins can manage other users' VPS."))
    vs = mine(target.id)
    if not vs: return await ctx.send(noreg(ctx.author) if target.id == ctx.author.id else f"❌ {target.mention} has no VPS.")
    v = pick(vs, num)
    if not v: return await ctx.send(f"❌ {target.mention} doesn't have VPS **#{num}**.")
    view = Manage(ctx.author.id, v["id"], str(target))
    note = f"{target.mention} has {len(vs)} VPS — use `{PREFIX}manage @user 2` etc." if len(vs) > 1 and not num else None
    view.msg = await ctx.send(note, embed=await asyncio.to_thread(panel, v, str(target)), view=view)

@bot.command()
async def sshx(ctx, num: int = None):
    vs = mine(ctx.author.id)
    if not vs: return await ctx.send(noreg(ctx.author))
    v = pick(vs, num)
    if not v: return await ctx.send(f"❌ {ctx.author.mention} you don't have VPS **#{num}**.")
    if v.get("suspended"): return await ctx.send(f"⛔ {ctx.author.mention} your VPS is suspended. Contact an admin.")
    await ctx.send(f"⏳ {ctx.author.mention} starting sshx, the link will arrive in your DM (≈10 sec)...")
    await sshx_flow(ctx.author, v, ctx.send, False)

# ---------------- admin ----------------
@bot.command()
async def addadmin(ctx, m: discord.Member = None):
    if ctx.author.id != MAIN: return await ctx.send(embed=deny("⛔ Access Denied", "Only the **main admin** can add admins."))
    if not m: return await ctx.send(f"Usage: `{PREFIX}addadmin @user`")
    json.dump(sorted(admins() | {m.id}), open(AF, "w"))
    await ctx.send(embed=ok("👑 Admin Added", f"{m.mention} is now an admin."))

@bot.command()
async def removeadmin(ctx, m: discord.Member = None):
    if ctx.author.id != MAIN: return await ctx.send(embed=deny("⛔ Access Denied", "Only the **main admin** can remove admins."))
    if not m or m.id == MAIN: return await ctx.send(f"Usage: `{PREFIX}removeadmin @user` (main admin can't be removed)")
    json.dump(sorted(admins() - {m.id, MAIN}), open(AF, "w"))
    await ctx.send(embed=ok("🗑️ Admin Removed", f"{m.mention} is no longer an admin.", 0xfee75c))

@bot.command(name="admins")
@admin_only()
async def admin_list(ctx):
    t = "\n".join(("👑 " if i == MAIN else "🛡️ ") + f"<@{i}>" for i in sorted(admins(), key=lambda i: i != MAIN))
    await ctx.send(embed=discord.Embed(title="🛡️ Admins", description=t, color=0x5865f2))

@bot.command(name="list")
@admin_only()
async def list_all(ctx):
    db = load()
    if not db: return await ctx.send("No VPS created yet.")
    rows = [f"{'⛔' if v.get('suspended') else '🟡' if v.get('pending') else '🟢'} <@{v['owner']}> **#{vnum(v)}** `{v['id']}` • {v['ram']:g}GB/{v['cpu']:g}C/{v['disk']:g}GB" for v in db]
    pager = Pager(ctx.author.id, [rows[k:k + 10] for k in range(0, len(rows), 10)])
    await ctx.send(embed=pager.embed(), view=pager if len(pager.pages) > 1 else None)

@bot.command(name="delete")
@admin_only()
async def delete_(ctx, m: discord.Member, which: str = None):
    w = which.lstrip("#") if which else None
    vs = [v for v in mine(m.id) if not w or str(vnum(v)) == w or v["id"] == w]
    if not vs: return await ctx.send(f"❌ {m.mention} has no matching VPS.")
    nums = [vnum(v) for v in vs]
    def rm():
        for v in vs: rm_container(v["name"])
        ids = {v["id"] for v in vs}; save([x for x in load() if x["id"] not in ids])
    await asyncio.to_thread(rm)
    await ctx.send(f"🗑️ {m.mention} deleted VPS " + ", ".join(f"**#{n}**" for n in nums) + ".")

@bot.command()
@admin_only()
async def suspend(ctx, m: discord.Member, *, reason: str = "No reason given"):
    vs = mine(m.id)
    if not vs: return await ctx.send(f"❌ {m.mention} has no VPS.")
    def go():
        for v in vs:
            update(v["id"], suspended=True, reason=reason)
            try: cont(v).stop(timeout=2)
            except Exception: pass
    await asyncio.to_thread(go)
    await ctx.send(embed=ok("⛔ VPS Suspended", f"{m.mention}'s **{len(vs)}** VPS stopped & locked.\n**Reason:** {reason}", 0xfee75c))
    try: await m.send(embed=deny("⛔ Your VPS was suspended", f"**Reason:** {reason}\nContact an admin."))
    except discord.Forbidden: pass

@bot.command()
@admin_only()
async def unsuspend(ctx, m: discord.Member):
    vs = mine(m.id)
    if not vs: return await ctx.send(f"❌ {m.mention} has no VPS.")
    def go():
        for v in vs:
            update(v["id"], suspended=False, reason=None)
            try: cont(v).update(restart_policy={"Name": "unless-stopped"}); cont(v).start()
            except Exception: pass
    await asyncio.to_thread(go)
    await ctx.send(embed=ok("✅ VPS Unsuspended", f"{m.mention}'s VPS are running again."))
    try: await m.send(f"✅ Your VPS is active again. Use `{PREFIX}manage`.")
    except discord.Forbidden: pass

@bot.command(aliases=["info"])
@admin_only()
async def userinfo(ctx, m: discord.Member):
    vs = mine(m.id)
    e = discord.Embed(title=f"👤 {m}", color=0x5865f2, description=f"VPS: **{len(vs)}** / limit **{ulimit(m.id)}**")
    for v in vs:
        try: st = "⛔ suspended" if v.get("suspended") else await asyncio.to_thread(lambda: cont(v).status)
        except Exception: st = "starting" if v.get("pending") else "missing"
        e.add_field(name=f"#{vnum(v)} `{v['id']}` — {st}", value=f"{v['ram']:g}GB • {v['cpu']:g}C • {v['disk']:g}GB\n`{v['name']}`" + (f"\n{v.get('reason')}" if v.get("suspended") else ""), inline=False)
    e.set_thumbnail(url=m.display_avatar.url); await ctx.send(embed=e)

@bot.command()
@admin_only()
async def setlimit(ctx, m: discord.Member, n: int):
    d = json.load(open(LF)) if os.path.exists(LF) else {}
    d[str(m.id)] = n; json.dump(d, open(LF, "w"))
    await ctx.send(embed=ok("📦 Limit Updated", f"{m.mention} can now have **{n}** VPS."))

@bot.command()
@admin_only()
async def resize(ctx, vid: str, ram: float, cpu: float):
    v = find(vid)
    if not v: return await ctx.send(f"❌ No VPS `{vid}` (use the VPS ID from `{PREFIX}list`).")
    def go():
        cont(v).update(mem_limit=f"{int(ram*1024)}m", memswap_limit=f"{int(ram*1024)}m", cpu_period=100000, cpu_quota=int(cpu*100000))
        update(vid, ram=ram, cpu=cpu)
    try: await asyncio.to_thread(go)
    except Exception as ex: return await ctx.send(embed=deny("❌ Failed", f"```{ex}```"))
    await ctx.send(embed=ok("📐 VPS Resized", f"`{vid}` → **{ram:g} GB RAM • {cpu:g} CPU** (disk can't change live)"))

@bot.command()
@admin_only()
async def reinstall(ctx, vid: str):
    v = find(vid)
    if not v: return await ctx.send(f"❌ No VPS `{vid}` (use the VPS ID from `{PREFIX}list`).")
    msg = await ctx.send(f"🔄 Reinstalling `{vid}` (fresh Ubuntu 24.04 with systemd)...")
    update(vid, pending=True)
    err = await asyncio.to_thread(provision, v)
    await msg.edit(content=f"✅ `{vid}` is fresh Ubuntu 24.04 again." if err is None else f"❌ Failed: `{err}`")

@bot.command()
@admin_only()
async def transfer(ctx, vid: str, m: discord.Member):
    v = find(vid)
    if not v: return await ctx.send(f"❌ No VPS `{vid}`.")
    if len(mine(m.id)) >= ulimit(m.id): return await ctx.send(f"❌ {m.mention} is at the VPS limit.")
    nums = {vnum(x) for x in mine(m.id)}; n = 1
    while n in nums: n += 1
    update(vid, owner=m.id, num=n)
    await ctx.send(f"🔁 `{vid}` now belongs to {m.mention} as **#{n}**.")

@bot.command()
@admin_only()
async def stats(ctx):
    def get():
        out = []
        for v in load():
            try: out.append((v, cont(v).status))
            except Exception: out.append((v, "missing"))
        return out
    db = await asyncio.to_thread(get)
    e = discord.Embed(title="📊 Rex Studio Stats", color=0x5865f2, timestamp=discord.utils.utcnow())
    e.add_field(name="🖥️ Total VPS", value=f"`{len(db)}`"); e.add_field(name="🟢 Running", value=f"`{sum(s == 'running' for _, s in db)}`")
    e.add_field(name="⛔ Suspended", value=f"`{sum(bool(v.get('suspended')) for v, _ in db)}`")
    e.add_field(name="👥 Users", value=f"`{len({v['owner'] for v, _ in db})}`")
    e.add_field(name="🧠 RAM allocated", value=f"`{sum(v['ram'] for v, _ in db):g} GB`"); e.add_field(name="⚙️ CPU allocated", value=f"`{sum(v['cpu'] for v, _ in db):g}`")
    await ctx.send(embed=e)

@bot.command()
@admin_only()
async def bootall(ctx, mode: str = None):
    msg = await ctx.send("⏳ Booting all VPS containers...")
    started, recreated, upgraded = await asyncio.to_thread(reconcile, True, mode == "systemd")
    await msg.edit(content=(f"✅ Boot done: started **{started}** stopped VPS, recreating **{recreated}** missing VPS"
        + (f", rebuilt **{upgraded}** VPS with systemd (data wiped)" if upgraded else "") + ". QEMU guard: **active**."))

@bot.command()
async def ping(ctx): await ctx.send(f"🏓 `{round(bot.latency*1000)} ms`")

@bot.command()
async def help(ctx):
    e = discord.Embed(title="🤖 Rex Studio VPS Bot", color=0x5865f2, description="Ubuntu 24.04 + systemd • instant deploy • sshx connect • QEMU guard")
    e.add_field(name="👤 Users", value=f"`{PREFIX}manage [number]` — control your VPS\n`{PREFIX}sshx [number]` — sshx link in DM\n`{PREFIX}ping`", inline=False)
    if is_admin(ctx.author.id):
        e.add_field(name="🛡️ Admins", value=(f"`{PREFIX}manage @user [number]` — open a user's panel\n`{PREFIX}create` • `{PREFIX}create <ram> <cpu> <disk> @user`\n"
            f"`{PREFIX}delete @user [number]` • `{PREFIX}suspend @user [reason]` • `{PREFIX}unsuspend @user`\n"
            f"`{PREFIX}userinfo @user` • `{PREFIX}setlimit @user n` • `{PREFIX}list` • `{PREFIX}stats` • `{PREFIX}admins`\n`{PREFIX}resize <id> <ram> <cpu>` • `{PREFIX}reinstall <id>` • `{PREFIX}transfer <id> @user`\n`{PREFIX}bootall` • `{PREFIX}bootall systemd` (wipes non-systemd VPS)"), inline=False)
    if ctx.author.id == MAIN:
        e.add_field(name="👑 Main Admin", value=f"`{PREFIX}addadmin @user` • `{PREFIX}removeadmin @user`", inline=False)
    e.set_footer(text="Rex Studio"); await ctx.send(embed=e)

if not TOKEN: sys.exit("DISCORD_TOKEN is missing in .env")
def wait_for_discord():                         # if Discord/Cloudflare banned this IP (429 / error 1015) just wait, don't hammer
    import urllib.request, urllib.error
    delay = 120
    opener = urllib.request.build_opener(*([urllib.request.ProxyHandler({"http": PROXY, "https": PROXY})] if PROXY else []))
    while True:
        try:
            opener.open(urllib.request.Request("https://discord.com/api/v10/gateway", headers={"User-Agent": "DiscordBot (https://github.com/Rapptz/discord.py, 2.4) rexbot"}), timeout=15); return
        except urllib.error.HTTPError as e:
            if e.code != 429: return
            print(f"Discord is blocking this server's IP for now (429 / Cloudflare 1015). Waiting {delay // 60} min, then trying again...", flush=True)
        except Exception as e:
            print("Network check failed:", repr(e), "- retrying in 1 min", flush=True); time.sleep(60); continue
        time.sleep(delay); delay = min(delay * 2, 1800)

def startup():                                  # runs even while Discord is blocking this IP
    ensure_image(); reconcile()
threading.Thread(target=startup, daemon=True).start()
threading.Thread(target=guard, daemon=True).start()
STARTED[0] = True

wait_for_discord()
try: bot.run(TOKEN)
except discord.HTTPException as e:
    if e.status == 429: print("Rate limited at login, backing off 10 min.", flush=True); time.sleep(600)
    raise
